<footer class="bg-light text-center py-3 mt-5">
    <p>Vizsga: 2025.06.07 - Név: Kota Ákos</p>
</footer>
<script src="main.js"></script>
</body>
</html>
